import React from 'react';
import { RiAncientGateFill, RiAlipayFill } from 'react-icons/ri';

function Test() {
  return (
    <div>
      <RiAncientGateFill style={{ width: '64px', height: '64px' }} />
      <RiAlipayFill style={{ width: '64px', height: '64px' }} />
      test
    </div>
  );
}

export default Test;
